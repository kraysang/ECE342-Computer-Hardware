/*
 * main.cpp
 *
 *  Created on: Feb 22, 2021
 *      Author: wangx753
 */

#include <system.h>
int main(void)
{
	int* led = (int*) LEDS_BASE;
	volatile int* sw = (int*)SWITCHES_BASE;

	while(true)
	{
		*(led) = *(sw);
	}
	return 0;
}

